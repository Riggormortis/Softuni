﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var firstPerson = new Person(20, "Pesho");
            var secondPerson = new Person(18, "Gosho");
            var thirdPerson = new Person(43, "Stamat");



        }
    }
}
