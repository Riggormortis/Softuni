﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {
        private List<int> internalList = new List<int>();

        public void Add(int item)
        {
            internalList.Add(item);
        }

        public int Remove()
        {
            int removedItem = internalList[internalList.Count - 1];
            internalList.RemoveAt(internalList.Count - 1);
            return removedItem;
        }

        public int Count => internalList.Count;  // => internalList.Count; == get{internalList.Count };
    }
}
